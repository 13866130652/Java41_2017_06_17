package cn.zuoye1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.Reader;
import java.io.Writer;

public class IODemo {

	// �����ļ��еķ���
	public static void createDirectory(String path) {
		File f = new File(path);
		if (!f.exists()) {
			if (f.mkdirs()) {
				System.out.println("Ŀ¼�����ɹ���");
			} else {
				System.out.println("Ŀ¼����ʧ�ܣ�");
			}
		} else {
			System.out.println("Ŀ¼�Ѵ��ڣ�");
		}
	}

	// �����ļ��ķ���
	public static void createFile(String path) {
		File f = new File(path);
		try {
			if (!f.exists()) {
				f.createNewFile();
				System.out.println("�ļ������ɹ���");
			} else {
				System.out.println("�ļ��Ѵ��ڣ�");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// ��FileReader��FileWriterʵ�ֶ�д����
	public static void readAndWrite(String p, String p1) {
		File f = new File(p);
		File f1 = new File(p1);

		Writer wt = null;
		Reader rd = null;
		try {
			rd = new FileReader(f);
			wt = new FileWriter(f1);
			int length = 0;
			char[] ch = new char[25];
			while ((length = rd.read(ch, 0, ch.length)) != -1) {
				wt.write(ch, 0, length);
			}
			wt.flush();
			wt.close();
			System.out.println("�ɹ����ƣ�");
			rd.close();
		} catch (Exception e) {

		}
	}

	// ��BufferedReader��BufferedWriterʵ�ֶ�д����
	public static void readAndWrite1(String p, String p1) {
		File f = new File(p);
		File f1 = new File(p1);
		BufferedReader br = null;
		BufferedWriter bw = null;
		try {
			br = new BufferedReader(new FileReader(f));
			bw = new BufferedWriter(new FileWriter(f1));
			String s = "";
			while ((s = br.readLine()) != null) {
				bw.write(s, 0, s.length());
				bw.newLine();
			}
			bw.flush();
			bw.close();
			br.close();
		} catch (Exception e) {

		}
	}

	// ͳ���ı���ĳһ�ַ��ĸ���
	public static void count(char s, String path) {
		File f = new File(path);
		Reader rd = null;
		try {
			rd = new FileReader(f);
			int date = 0, num = 0;
			while ((date = rd.read()) != -1) {
				if ((char) date == s) {
					num++;
				}
			}
			rd.close();
			System.out.println("�ַ�" + s + "�ĸ����ǣ�" + num);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// ������ĳһ�ַ�,����д��ȥ
	public static void change(char oldChar, char newChar, String path, String path1) {
		File f = new File(path);
		File f1 = new File(path1);
		BufferedReader rd = null;
		BufferedWriter wt = null;
		try {
			rd = new BufferedReader(new FileReader(f));
			wt = new BufferedWriter(new FileWriter(f1));
			StringBuffer sb = new StringBuffer();
			String s = "";
			while ((s = rd.readLine()) != null) {
				char[] ch = s.toCharArray();
				for (int i = 0; i < ch.length; i++) {
					if (ch[i] == oldChar) {
						sb.append(newChar);
					} else {
						sb.append(ch[i]);
					}
				}
			}
			wt.write(sb.toString());
			wt.flush();
			wt.close();
			rd.close();
		} catch (Exception e) {

		}
	}

	public static void main(String[] args) {
		// 1.����Ŀ¼
		createDirectory("F:/filedemo/myio");
		// 2.�����ļ�
		createFile("F:/filedemo/myio/text.txt");
		// 3.��FileReader��FileWriterʵ�ֶ�д����

		readAndWrite("F:/filedemo/test.txt", "F:/filedemo/myio/text.txt");
		// 4.��BufferedReader��BufferedWriterʵ�ֶ�д����
		createDirectory("F:/filedemo/myio/input");
		readAndWrite1("F:/filedemo/myio/text.txt", "F:/filedemo/myio/input/text1.txt");
		// 5. ͳ���ı���'a'�ĸ���
		count('a', "F:/filedemo/test.txt");
		// 6.��test.txt�еġ�a���ַ�ת���ɡ�b�������D:\myio\input\test2.txt��
		change('a', 'b', "F:/filedemo/myio/text.txt", "F:/filedemo/myio/input/text2.txt");
	}

}
