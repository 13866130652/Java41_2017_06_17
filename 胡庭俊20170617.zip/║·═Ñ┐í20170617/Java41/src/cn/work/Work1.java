package cn.work;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.Reader;

//����ļ�����
public class Work1 {
	private static File fl = new File("D:\\test1.txt");

	public static int sum() {
		try {
			int i = 0;
			Reader re = new FileReader(fl);
			BufferedReader bre = new BufferedReader(re);
			String st = null;
			//���Դ�ļ��е�����������
			while ((st = bre.readLine()) != null) {
				i++;
			}
			return i;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
}
