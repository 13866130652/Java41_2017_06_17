package cn.bdqn;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Demo {
	// �����������������
	private static BufferedReader br = null;
	private static BufferedWriter bw = null;

	// 1.����Ŀ¼
	public static void createDirectory(String path) {
		if (path != null) {
			File f = new File(path);
			if (!f.exists()) {
				if (f.mkdir()) {
					System.out.println("����Ŀ¼" + path + "�ɹ�");
				}
			} else {
				System.out.println(path + "Ŀ¼�Ѵ��ڣ�");
			}
		}
	}

	// 2.�����ļ�
	public static File createFile(String path) {
		if (path != null) {
			File f = new File(path);
			if (!f.exists()) {
				try {
					if (f.createNewFile()) {
						System.out.println("�����ļ��ɹ�,�ļ����ǣ�" + f.getName());
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			} else {
				System.out.println("��Ŀ���ļ��Ѵ��ڣ�");
			}
			return f;
		}
		return null;

	}

	// 3.��test.txt�ļ���д��������������
	public static void write(File f, String msg) {
		try {
			bw = new BufferedWriter(new FileWriter(f));
			bw.write(msg);
			System.out.println("����д��ɹ���");
			bw.flush();
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// 4.��test.txt�ļ��е����ݸ��Ƶ�D:\myio\input\test1.txt��
	public static void translate(String origin, String target) {
		try {
			br = new BufferedReader(new FileReader(origin));
			try {
				bw = new BufferedWriter(new FileWriter(target));
				String st = "";
				while ((st = br.readLine()) != null) {
					bw.write(st);
					bw.newLine();
				}
				System.out.println("���ݸ��Ƴɹ���");
				bw.flush();
				bw.close();
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	// 5.ͳ��test.txt�ļ��ġ�a������
	public static int getNum(String path, char ch) {
		int s = 0, num = 0;
		try {
			br = new BufferedReader(new FileReader(path));

			try {
				while ((s = br.read()) != -1) {
					if (s == ch) {
						num++;
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return num;
	}

	// 6.��test.txt�еġ�a���ַ�ת���ɡ�b�������D:\myio\input\test2.txt��
	public static void change(String origin, String target) {
		StringBuffer sb = new StringBuffer();
		String st = "";
		try {
			br = new BufferedReader(new FileReader(origin));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		try {
			bw = new BufferedWriter(new FileWriter(target));
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			while ((st = br.readLine()) != null) {
				sb.append(st);
			}
			bw.write(sb.toString().replace('a', 'b'));
			System.out.println("'a'�滻��'b'��д�ɹ���");
			bw.flush();
			bw.close();
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static void main(String[] args) {
		System.out.println("******1.createDirectory(String path)********");
		createDirectory("E:\\myOO\\a");
		System.out.println("********2.createFile(String path)**********");
		File f = createFile("E:\\myOO\\a\\test.txt");
		System.out.println("*********3.write(File f, String msg)**********");
		String st = "A local teenager has replaced all her" + //
				" digital tracks with vinyl. It's really groovy," + //
				" she said, on the record. Without skipping a beat, " + //
				"she added, Besides, it's like going through a time warp." + //
				"Some of her iPod-toting classmates aren't as enthusiastic. " + //
				"Yeah, they needle me about it. What a bunch of ones and zeros.";
		write(f, st);
		System.out
				.println("******4.����translate(String origin, String target)********");
		translate("E:\\myOO\\a\\test.txt", "E:\\myOO\\a\\test1.txt");
		System.out
				.println("******5.��д��a������b��..change(String origin, String target)********");
		change("E:\\myOO\\a\\test.txt", "E:\\myOO\\a\\test2.txt");
		System.out.println("******6.ͳ�Ƹ���getNum(String origin, char c)********");
		System.out.println("�ļ�test.txt�С�a����"
				+ getNum("E:\\myOO\\a\\test.txt", 'a') + "��");

	}
}
