package cn.dpp;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

public class Demo {
	// �����ַ�����������
	private static BufferedReader br = null;
	// �����ַ����������
	private static BufferedWriter bw = null;

	// ����Ŀ¼
	public static void mkdir1(String path) {
		File file = new File(path);
		if (!file.exists()) {
			file.mkdirs();
			System.out.println("Ŀ¼�����ɹ���");
		} else {
			System.out.println("Ŀ¼�Ѵ��ڣ�");
		}
	}

	// �����ļ�
	public static void creat(String path) {
		File file = new File(path);
		if (!file.exists()) {
			try {
				file.createNewFile();
			} catch (Exception e) {
				e.printStackTrace();
			}
			System.out.println("�ļ������ɹ���");
		} else {
			System.out.println("�ļ��Ѵ��ڣ�");
		}
	}

	// д��
	public static void write1(String path, String path1) {
		try {
			br = new BufferedReader(new FileReader(path));
			bw = new BufferedWriter(new FileWriter(path1));
			String st = "";
			while ((st = br.readLine()) != null) {
				bw.write(st);
				bw.newLine();
			}
			bw.flush();
			System.out.println("д��ɹ���");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// ͳ��ĳ���ַ����ֵĴ���
	public static void count(String path, char s) {
		try {
			br = new BufferedReader(new FileReader(path));
			int data = 0, num = 0;
			while ((data = br.read()) != -1) {
				if ((char) (data) == s) {
					num++;
				}
			}
			System.out.println("�ļ���" + s + "�ĸ���Ϊ��" + num);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// �滻
	public static void change(String path, String path1, char old, char new1) {
		try {
			br = new BufferedReader(new FileReader(path));
			bw = new BufferedWriter(new FileWriter(path1));
			String st = "";
			while ((st = br.readLine()) != null) {
				st = st.replace(old, new1);
				bw.write(st);
				bw.newLine();// ���з�
			}
			bw.flush();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// �ر���
	public static void close() {
		try {
			if (bw != null) {
				bw.close();
			}
			if (br != null) {
				br.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static void main(String[] args) {
		mkdir1("D:\\myio\\input");
		creat("D:\\myio\\test.txt");
		creat("D:\\myio\\input\\test1.txt");
		write1("D:\\myio\\�½��ı��ĵ�.txt", "D:\\myio\\test.txt");
		write1("D:\\myio\\test.txt", "D:\\myio\\input\\test1.txt");
		count("D:\\myio\\test.txt", 'a');
		change("D:\\myio\\test.txt", "D:\\myio\\input\\test2.txt", 'a', 'b');
		close();
	}

}
