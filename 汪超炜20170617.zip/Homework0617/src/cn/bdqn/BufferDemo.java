package cn.bdqn;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;

public class BufferDemo {
	public static void main(String[] args) throws IOException {

		File file = new File("D:\\myio","test.txt");
		if (!file.exists()) {
			file.getParentFile().mkdir();
			System.out.println("����Ŀ¼�ɹ�");
			file.createNewFile();
			System.out.println("�����ļ��ɹ�");
			
		} else {
			System.out.println("Ŀ��·��" + file + "�Ѵ���");
		}

		Writer wt=new FileWriter(file);
		BufferedWriter bw=new BufferedWriter(wt);
		String s="A local teenager has replaced all her digital tracks with vinyl."
				+ "��It's really groovy,�� she said, on the record. Without skipping a beat, "
				+ "she added, ��Besides, it's like going through a time warp.��"
				+ "Some of her iPod-toting classmates aren't as enthusiastic. "
				+ "��Yeah, they needle me about it. What a bunch of ones and zeros.��";
		char[] ch=s.toCharArray();
		bw.write(ch, 0, ch.length);
		bw.flush();
		bw.close();
		File f=new File("D:\\myio\\input","test1.txt");
		if (!f.exists()) {
			f.getParentFile().mkdir();
			System.out.println("����Ŀ¼�ɹ�");
			f.createNewFile();
			System.out.println("�����ļ��ɹ�");
			
		} else {
			System.out.println("Ŀ��·��" + f + "�Ѵ���");
		}
		Reader rd=new FileReader(file);
		Writer w=new FileWriter(f);
		BufferedWriter b=new BufferedWriter(w);
		char[] ch1=new char[1024];
		int data=0;
		while((data=rd.read(ch1))!=-1){
			b.write(ch1);
			b.flush();
			b.close();
			System.out.println("���Ƴɹ���");
		}
		int n=0;
		for(int i=0;i<ch1.length;i++){
			if(ch1[i]=='a'){
				n++;
			}
		}
		System.out.println("a�ĸ����У�"+n);
		Writer wr=new FileWriter("D:\\myio\\input\\test2.txt");
		BufferedWriter bu=new BufferedWriter(wr);
		
			for(int i=0;i<ch1.length;i++){
				if(ch1[i]=='a'){
					ch1[i]='b';
				}
			}
			bu.write(ch1);
			bu.flush();
			bu.close();
			System.out.println("��д�ɹ���");
	
		
	}

}
